# Music Player — marcos M0 e M1

App Android nativo (Kotlin, Jetpack Compose, Media3) para tocar músicas do próprio celular, inclusive
com a tela bloqueada. Este pacote entrega:

- **M0:** esqueleto do projeto e build na nuvem (GitHub Actions).
- **M1:** player local com reprodução em segundo plano, notificação com controles e controles na tela
  de bloqueio.

> **Status honesto:** nada deste projeto foi compilado nem executado ainda (o ambiente onde ele foi
> escrito não tem Android SDK, Gradle nem rede). O primeiro build no GitHub Actions é o primeiro teste
> de compilação. Se falhar, o log diz o motivo e eu corrijo.

## Gerar o APK pelo celular (sem computador)

1. Entre em github.com pelo navegador (crie uma conta gratuita, se ainda não tiver).
2. Crie um repositório **privado**: botão **+** > **New repository** > nome `music-player` >
   **Private** > marque **Add a README file** > **Create repository**.
3. No repositório: **Add file** > **Upload files** > escolha o `music-player.zip` (não descompacte) >
   **Commit changes**.
4. **Add file** > **Create new file**. No campo do nome digite exatamente `.github/workflows/build.yml`.
   Cole todo o conteúdo do arquivo `build.yml` que veio junto e toque em **Commit changes**.
5. Abra a aba **Actions**. O fluxo **Build APK** começa sozinho (de 5 a 15 minutos na primeira vez).
6. Quando ficar verde, abra `https://github.com/SEU-USUARIO/music-player/releases`, entre em
   **Build 1-1** e baixe o arquivo `.apk` em **Assets**.
7. Abra o APK no celular e permita instalar apps desta fonte quando o Android pedir.

**Atualizar:** envie um novo `music-player.zip` com o mesmo nome (**Add file** > **Upload files**); ele
substitui o anterior e gera um novo build. Todos os builds usam a mesma assinatura (chave de debug
fixa), então o APK novo instala por cima do antigo sem apagar os dados.

**Se o build falhar** (ícone vermelho): abra a execução, toque no passo marcado com ✗, copie as últimas
40 linhas do log e envie para mim.

**Não suba os áudios de teste do kit para o repositório.** Importe-os pelo próprio app.

## Instalação bloqueada? (verificação de desenvolvedor do Android)

Desde 30/09/2026, em aparelhos Android com Google certificado no **Brasil, Indonésia, Singapura e
Tailândia**, apps de desenvolvedores não verificados não instalam pelo caminho normal. As saídas
previstas pelo Google (conferidas em 08/11/2026 no blog e no site oficial do Android):

- **Fluxo avançado de instalação:** exige ativar o modo desenvolvedor, confirmar os avisos e esperar
  24 horas na primeira vez; depois dá para liberar por 7 dias ou sem prazo.
- **Conta de distribuição limitada:** gratuita, sem documento oficial (só e-mail), até 20 aparelhos.
  Você registra o pacote `app.musicplayer` com a assinatura do APK. Para isso vamos precisar trocar a
  chave de debug por uma chave sua, privada.
- **ADB:** instalação por cabo ou depuração sem fio a partir de um computador.

Ainda não sei se isso afeta o seu aparelho. Se o Android bloquear a instalação, me avise e escolhemos o
caminho.

## O que o M1 faz

- Importa arquivos de áudio pelo seletor de arquivos do sistema (sem permissão ampla de armazenamento).
- Lê título, artista, álbum e duração do arquivo. Sem tags, usa o nome do arquivo.
- Valida pelo **conteúdo**: um MP4 renomeado para `.mp3` (como o 2º áudio do kit) é reconhecido como
  "arquivo com vídeo" e toca só o áudio.
- Toca em segundo plano e com a tela bloqueada (serviço de mídia em primeiro plano).
- Notificação com controles, controles na tela de bloqueio e botão do fone.
- Player em tela cheia: play/pause, anterior, próxima, barra de progresso, aleatório e repetir.
- Pula faixa com erro; trata foco de áudio (chamadas, outros apps) e fone desconectado.
- Tema escuro (padrão) e claro, com as cores da identidade visual.

## O que o M1 ainda NÃO faz

- A biblioteca não persiste ao fechar o app (Room entra no M2). Por isso, ao reabrir com música
  tocando, o mini-player aparece mas a lista fica vazia: é esperado nesta fase.
- Sem capas, busca, playlists, favoritos, histórico e fonte online (M2 a M5).
- Sem tela de configurações; a escolha de tema não é salva (M4).

## Teste manual

Veja `docs/TESTES_M1.md`. A reprodução com a tela desligada só pode ser aprovada em aparelho real.

## Estrutura

```
app/src/main/kotlin/app/musicplayer/
  MainActivity.kt           ponto de entrada (Compose, tema)
  playback/PlaybackService  serviço de mídia: ExoPlayer + MediaSession + notificação
  data/                     LocalTrack e leitura de metadados (TrackImporter)
  ui/                       telas em Compose e PlayerViewModel (MediaController)
  util/Formatters.kt        título a partir do nome do arquivo e formatação de duração
app/src/test/               testes unitários (rodam no GitHub Actions)
docs/                       decisões, arquitetura e plano de testes
.github/workflows/build.yml fluxo de build na nuvem
```

## Compilar no computador (opcional)

Android Studio recente, JDK 17 e Gradle 8.14.3 (o projeto não traz o Gradle Wrapper). Abra a pasta no
Android Studio ou rode `gradle assembleDebug`. O APK sai em `app/build/outputs/apk/debug/`.

## Versões

Detalhes e o que foi ou não conferido na documentação oficial: `docs/DECISOES.md`.
