# Regras do R8 para o build release (ainda não usado nos marcos M0 e M1).
