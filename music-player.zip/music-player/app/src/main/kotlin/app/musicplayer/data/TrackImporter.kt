package app.musicplayer.data

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import app.musicplayer.util.FileNames

/**
 * Lê os metadados de um arquivo escolhido pelo seletor do sistema. A validação é feita pelo
 * CONTEÚDO do arquivo, não pela extensão: um MP4 com nome .mp3 é reconhecido como "tem vídeo".
 */
object TrackImporter {

    fun read(context: Context, uri: Uri): LocalTrack? {
        val resolver = context.contentResolver
        keepAccess(resolver, uri)

        val displayName = queryDisplayName(resolver, uri) ?: uri.lastPathSegment ?: "arquivo"
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.takeIf { it.isNotBlank() }
                ?: FileNames.titleFromFileName(displayName)
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty().trim()
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty().trim()
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
            LocalTrack(
                uri = uri,
                title = title.trim(),
                artist = artist,
                album = album,
                durationMs = duration,
                hasVideo = hasVideo,
                displayName = displayName,
            )
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // nada a fazer
            }
        }
    }

    /** Pede permissão persistente de leitura para o arquivo continuar acessível depois. */
    private fun keepAccess(resolver: ContentResolver, uri: Uri) {
        try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // O provedor não oferece permissão persistente: o acesso vale só nesta sessão.
        } catch (e: UnsupportedOperationException) {
            // idem
        }
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        return try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
