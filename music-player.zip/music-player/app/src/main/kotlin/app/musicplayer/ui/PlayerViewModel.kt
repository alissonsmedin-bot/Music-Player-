package app.musicplayer.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.musicplayer.data.LocalTrack
import app.musicplayer.data.TrackImporter
import app.musicplayer.playback.PlaybackService
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Retrato do estado do player para a interface. */
data class PlayerUiState(
    val hasMedia: Boolean = false,
    val currentIndex: Int = -1,
    val title: String = "",
    val artist: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
)

/**
 * Liga a interface ao serviço de reprodução por meio de um MediaController. Todas as chamadas ao
 * controller acontecem na thread principal, como o Media3 exige.
 */
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val _tracks = MutableStateFlow<List<LocalTrack>>(emptyList())
    val tracks: StateFlow<List<LocalTrack>> = _tracks.asStateFlow()

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            publishState(player)
        }

        override fun onPlayerError(error: PlaybackException) {
            _messages.tryEmit("Não foi possível reproduzir este arquivo.")
        }
    }

    init {
        connectToService()
        startPositionTicker()
    }

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                try {
                    val connected = future.get()
                    controller = connected
                    connected.addListener(playerListener)
                    publishState(connected)
                } catch (e: Exception) {
                    _messages.tryEmit("Falha ao conectar ao serviço de reprodução.")
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    private fun publishState(player: Player) {
        val item = player.currentMediaItem
        val duration = player.duration
        _uiState.value = PlayerUiState(
            hasMedia = item != null,
            currentIndex = player.currentMediaItemIndex,
            title = item?.mediaMetadata?.title?.toString().orEmpty(),
            artist = item?.mediaMetadata?.artist?.toString().orEmpty(),
            isPlaying = player.isPlaying ||
                (player.playWhenReady && player.playbackState == Player.STATE_BUFFERING),
            positionMs = player.currentPosition.coerceAtLeast(0L),
            durationMs = if (duration == C.TIME_UNSET) 0L else duration.coerceAtLeast(0L),
            shuffle = player.shuffleModeEnabled,
            repeatMode = player.repeatMode,
        )
    }

    /** Atualiza a posição da barra enquanto a música toca. */
    private fun startPositionTicker() {
        viewModelScope.launch {
            while (isActive) {
                delay(500)
                val current = controller
                if (current != null && current.isPlaying) {
                    val position = current.currentPosition.coerceAtLeast(0L)
                    _uiState.update { it.copy(positionMs = position) }
                }
            }
        }
    }

    // ---- Ações da interface ----

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val app = getApplication<Application>()
            val imported = withContext(Dispatchers.IO) {
                uris.mapNotNull { TrackImporter.read(app, it) }
            }
            val known = _tracks.value.map { it.uri }.toSet()
            val fresh = imported.filter { it.uri !in known }
            _tracks.update { it + fresh }

            val failed = uris.size - imported.size
            if (failed > 0) {
                _messages.tryEmit("$failed arquivo(s) não puderam ser lidos.")
            } else if (fresh.isEmpty()) {
                _messages.tryEmit("Esses arquivos já estão na biblioteca.")
            }
        }
    }

    /** Toca a biblioteca inteira como fila, começando pela faixa escolhida. */
    fun playTrack(index: Int) {
        val current = controller ?: return
        val list = _tracks.value
        if (index !in list.indices) return
        current.setMediaItems(list.map { it.toMediaItem() }, index, C.TIME_UNSET)
        current.prepare()
        current.play()
    }

    fun togglePlayPause() {
        val current = controller ?: return
        when {
            current.playbackState == Player.STATE_ENDED -> {
                current.seekTo(0L)
                current.play()
            }
            current.playWhenReady -> current.pause()
            else -> {
                if (current.playbackState == Player.STATE_IDLE) current.prepare()
                current.play()
            }
        }
    }

    fun skipNext() {
        controller?.seekToNext()
    }

    fun skipPrevious() {
        controller?.seekToPrevious()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val current = controller ?: return
        current.shuffleModeEnabled = !current.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val current = controller ?: return
        current.repeatMode = when (current.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        controllerFuture = null
        super.onCleared()
    }
}
