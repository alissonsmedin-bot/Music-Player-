package app.musicplayer.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Paleta estimada por amostragem de pixels das imagens de referência (não são valores oficiais).
// Observação: inverseSurface, inverseOnSurface e inversePrimary são usados como as cores do
// mini-player (pílula escura com destaque limão), nos dois temas.

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9FE753),
    onPrimary = Color(0xFF0A2A25),
    primaryContainer = Color(0xFF14463E),
    onPrimaryContainer = Color(0xFFD9F7A8),
    secondary = Color(0xFF31C58C),
    onSecondary = Color(0xFF00261F),
    secondaryContainer = Color(0xFF0F4A41),
    onSecondaryContainer = Color(0xFFBDEFD9),
    tertiary = Color(0xFFC2FD67),
    onTertiary = Color(0xFF1A2E00),
    background = Color(0xFF061F1B),
    onBackground = Color(0xFFE6F2EC),
    surface = Color(0xFF0B2B26),
    onSurface = Color(0xFFE6F2EC),
    surfaceVariant = Color(0xFF12403A),
    onSurfaceVariant = Color(0xFFA9C7BD),
    outline = Color(0xFF5E8C81),
    inverseSurface = Color(0xFF14463E),
    inverseOnSurface = Color(0xFFEAF5EF),
    inversePrimary = Color(0xFF9FE753),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF075046),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9F7A8),
    onPrimaryContainer = Color(0xFF052E27),
    secondary = Color(0xFF1F9E70),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCDEFE0),
    onSecondaryContainer = Color(0xFF053B30),
    tertiary = Color(0xFF5CA81B),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFFAFAF7),
    onBackground = Color(0xFF212223),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF212223),
    surfaceVariant = Color(0xFFE9F1EC),
    onSurfaceVariant = Color(0xFF4A5C56),
    outline = Color(0xFF7B8E87),
    inverseSurface = Color(0xFF212223),
    inverseOnSurface = Color(0xFFF4F7F2),
    inversePrimary = Color(0xFF9FE753),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

@Composable
fun MusicPlayerTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = AppShapes,
        content = content,
    )
}
