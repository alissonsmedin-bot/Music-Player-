package app.musicplayer.util

import java.util.Locale

object FileNames {
    private val uuidSuffix =
        Regex("[\\s_-]+[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\$")
    private val manySpaces = Regex("\\s+")

    /** Título legível a partir do nome do arquivo: sem extensão, sem sufixo UUID e sem underscores. */
    fun titleFromFileName(fileName: String): String {
        var base = fileName.trim()
        val dot = base.lastIndexOf('.')
        if (dot > 0 && base.length - dot <= 6) {
            base = base.substring(0, dot)
        }
        base = uuidSuffix.replace(base, "")
        base = manySpaces.replace(base.replace('_', ' '), " ").trim()
        return base.ifEmpty { fileName.trim() }
    }
}

/** Formata milissegundos como m:ss (ou h:mm:ss). */
fun formatDuration(millis: Long): String {
    if (millis <= 0L) return "0:00"
    val totalSeconds = millis / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.ROOT, "%d:%02d", minutes, seconds)
    }
}
