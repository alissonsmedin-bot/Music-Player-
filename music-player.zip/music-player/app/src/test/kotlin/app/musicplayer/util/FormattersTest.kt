package app.musicplayer.util

import org.junit.Assert.assertEquals
import org.junit.Test

class FormattersTest {

    @Test
    fun titulo_remove_extensao_e_underscores() {
        assertEquals("AhaTik som original", FileNames.titleFromFileName("AhaTik_som original.mp3"))
    }

    @Test
    fun titulo_remove_sufixo_uuid() {
        val nome = "AhaTik_som original_e5f2adf4-1111-2222-3333-444455556666.mp3"
        assertEquals("AhaTik som original", FileNames.titleFromFileName(nome))
    }

    @Test
    fun titulo_sem_extensao_permanece() {
        assertEquals("Minha musica", FileNames.titleFromFileName("Minha musica"))
    }

    @Test
    fun titulo_colapsa_espacos_repetidos() {
        assertEquals("a b c", FileNames.titleFromFileName("a__b   c.flac"))
    }

    @Test
    fun duracao_zero_ou_negativa() {
        assertEquals("0:00", formatDuration(0L))
        assertEquals("0:00", formatDuration(-5L))
    }

    @Test
    fun duracao_em_minutos_e_segundos() {
        assertEquals("0:59", formatDuration(59_999L))
        assertEquals("1:05", formatDuration(65_000L))
        assertEquals("18:36", formatDuration(1_116_000L))
    }

    @Test
    fun duracao_com_horas() {
        assertEquals("1:01:01", formatDuration(3_661_000L))
    }
}
