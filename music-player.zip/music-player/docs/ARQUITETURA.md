# Arquitetura atual (M1)

```
Interface (Jetpack Compose)  ──►  PlayerViewModel  ──►  MediaController
                                                              │  (liga ao serviço)
                                                              ▼
                                        PlaybackService (MediaSessionService, primeiro plano)
                                            ├─ ExoPlayer  (música; vídeo desativado)
                                            └─ MediaSession ──► notificação de mídia, tela de bloqueio,
                                                                 botões de fone/Bluetooth
```

- **Importação:** `ActivityResultContracts.OpenMultipleDocuments` entrega URIs; `TrackImporter` pede
  permissão persistente de leitura e lê os metadados com `MediaMetadataRetriever`.
- **Fila:** ao tocar uma faixa, a biblioteca inteira vira fila no ExoPlayer, começando pela faixa
  escolhida. Aleatório e repetir são do próprio player.
- **Segundo plano:** o player vive no serviço, não na tela. Fechar a tela não interrompe a música.
- **Foco de áudio e fone:** tratados pelo ExoPlayer (`handleAudioFocus` e `handleAudioBecomingNoisy`).
- **Erros:** faixa com falha é pulada; a interface mostra uma mensagem.
- **Ao deslizar o app dos recentes:** comportamento padrão do Media3 (continua se estiver tocando;
  encerra o serviço se estiver pausado).
- **Permissões:** `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `POST_NOTIFICATIONS`
  (pedida na primeira reprodução) e `WAKE_LOCK`. Nada de internet, localização ou microfone.
