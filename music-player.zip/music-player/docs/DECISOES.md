# Registro de decisões técnicas (continuação do relatório)

As decisões D-001 a D-007 estão no relatório técnico (seção 8). Aqui ficam as seguintes.

| ID | Decisão | Motivo |
|---|---|---|
| D-008 | No M1 o serviço herda de `MediaSessionService`, não de `MediaLibraryService` | Menos superfície de erro sem compilador local. `MediaLibraryService` é subclasse e entra quando houver Android Auto ou navegação de biblioteca. Refina o item 6.4 do relatório. |
| D-009 | Tema escuro como padrão, com opção de claro | Você delegou a escolha. O briefing pede tema escuro inicial e a paleta verde-escuro e limão da identidade funciona bem no escuro. O padrão pode ser trocado em uma linha. |
| D-010 | AGP 8.13.0, Gradle 8.14.3, Kotlin 2.3.10, JDK 17, compileSdk 37, targetSdk 36, minSdk 26 | AGP 9 exige Kotlin embutido e a nova DSL; sem poder compilar localmente, preferi a DSL clássica. compileSdk 37 evita erro de biblioteca que exija API mais nova que 36; o aviso do AGP é silenciado em `gradle.properties`. |
| D-011 | O projeto vai ao GitHub como um único `music-player.zip` e o fluxo descompacta | Subir dezenas de arquivos e pastas pelo celular é inviável. Um ZIP só é um upload. |
| D-012 | Chave de debug fixa dentro do projeto (`app/debug.keystore`, senha padrão `android`) | Mantém a mesma assinatura em todos os builds, para o APK novo instalar por cima do antigo. Não é segredo. Será trocada por chave privada antes de qualquer uso mais sério. |
| D-013 | Sem persistência no M1 (a lista de músicas vive na memória) | Room e a persistência são o objetivo do M2. |
| D-014 | Ícones de `material-icons-extended` provisórios | Rapidez. No M4 entram ícones próprios alinhados à identidade. |
| D-015 | Aviso sobre a verificação de desenvolvedor do Android | Pode bloquear a instalação do APK em Brasil, Indonésia, Singapura e Tailândia. Ver README. |

## Versões: o que foi conferido

| Item | Versão | Origem |
|---|---|---|
| Media3 | 1.11.1 | Página oficial de releases do Media3 (estável; atualização de 26/10/2026) |
| Compose BOM | 2026.08.00 | Documentação oficial do BOM do Compose (versão citada nos exemplos) |
| Kotlin | 2.3.10 | Citada no AGENT.md do Echo Music, que compila com ela |
| activity-compose 1.12.3, lifecycle 2.10.0, core-ktx 1.16.0 | — | Versões gravadas no APK do Echo Music, que compila com elas |
| AGP 8.13.0 e Gradle 8.14.3 | — | **De memória, não conferidas nesta sessão.** Se o build reclamar, ajustamos. |
| JDK 17 | — | Requisito mínimo do AGP 8 e 9 |

Notas do Media3 1.11 relevantes: as chamadas ao player devem ocorrer na thread principal (a interface
já faz isso); controladores de terceiros só têm acesso de leitura por padrão (o app e o sistema são
confiáveis); houve correções de falhas ao iniciar serviço em primeiro plano.

## Pendências

- Modelo e versão do Android do aparelho (para escolher o plano de teste e o caminho de instalação).
- País/região do aparelho, por causa da verificação de desenvolvedor.
- Client ID gratuito da Jamendo (marco M5); eu guio o passo a passo quando chegarmos lá.
