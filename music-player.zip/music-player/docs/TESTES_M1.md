# Plano de testes do M1

Preencha a coluna **Resultado** depois de executar no aparelho. Nenhum destes testes foi executado
ainda. Marque: OK, FALHOU (com o que aconteceu) ou NÃO TESTADO.

| # | Teste | Como fazer | Esperado | Resultado |
|---|---|---|---|---|
| 1 | Instalar e abrir | Instalar o APK e abrir o app | Abre sem travar; tema escuro; lista vazia com botão Importar | |
| 2 | Importar os 2 áudios do kit | Importar músicas > escolher os dois arquivos | Aparecem 2 faixas; a 2ª marcada como arquivo com vídeo; títulos sem underscores | |
| 3 | Tocar o 1º áudio (MP3 de 18 s) | Tocar na faixa | Som; mini-player; barra avança; Android pede permissão de notificações (Android 13+) | |
| 4 | Tocar o 2º áudio (MP4 de 60 s) | Tocar na faixa | Toca só o áudio; sem travar; duração perto de 1:00 | |
| 5 | Controles do player | Abrir o player; pausar, retomar, próxima, anterior, arrastar a barra | Tudo responde sem atraso | |
| 6 | Aleatório e repetir | Alternar aleatório; repetir tudo e uma faixa | Ordem e repetição corretas | |
| 7 | Segundo plano | Tocando, ir para a tela inicial | Continua tocando | |
| 8 | Tela bloqueada | Bloquear por 10 minutos ou mais | Continua; controles na tela de bloqueio funcionam | |
| 9 | Notificação | Usar play/pausa/próxima na notificação; tocar nela | Estado do app acompanha; tocar abre o app | |
| 10 | Notificações negadas | Negar a permissão e tocar uma música | Anotar o que acontece (toca? controles aparecem?) | |
| 11 | Chamada ou outro app de áudio | Receber chamada ou abrir outro player | Pausa e retoma de forma previsível | |
| 12 | Fones | Botão do fone; desconectar o fone | Botão controla; desconectar pausa | |
| 13 | Deslizar dos recentes | Tocando: deslizar o app. Depois pausado: deslizar | Tocando continua; pausado encerra o serviço | |
| 14 | Arquivo inválido | Importar um arquivo de texto renomeado para .mp3 | Mensagem de erro; sem travar | |
| 15 | Rotação e tema | Girar a tela; alternar tema claro e escuro | Estado preservado; legível nos dois temas | |
| 16 | Reabrir com música tocando | Fechar o app com música tocando e reabrir | Mini-player aparece; lista vazia (esperado no M1) | |
| 17 | Bateria | 30 minutos com a tela apagada | Anotar o consumo em Configurações > Bateria | |

Teste automatizado: `FormattersTest` (título a partir do nome do arquivo e formatação de duração) roda
no GitHub Actions; o resultado fica no log do passo **Testes unitarios**.
